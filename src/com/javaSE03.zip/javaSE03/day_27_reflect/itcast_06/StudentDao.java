package com.javaSE03.day_27_reflect.itcast_06;

public interface StudentDao {
	public abstract void login();

	public abstract void regist();
}

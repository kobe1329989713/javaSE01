package com.javaSE03.day_27_reflect.pattern.itcast_02;

public class IPhone implements Phone {

	@Override
	public void call() {
		System.out.println("�ֻ����Դ�绰��");
	}

}

package com.javaSE03.day_27_reflect.pattern.itcast_02;

public interface Phone {
	public abstract void call();
}
